var data = {
    us: {
        Catheter_Associated_Urinary_Tract_Infections: 19,
        Central_Line_Associated_Bloodstream_Infections: 5,
        Clostridium_Difficile_C_Diff_Infections: 8,
        MRSA_Bacteremia_Infections: 30,
        Abdominal_Hysterectomy_Infections: 10, 
        SSI_Colon_Surgery_Infections: 18,
        Hospital_Acquired_Infections: 6
    },

    ak: {
        Catheter_Associated_Urinary_Tract_Infections: 10,
        Central_Line_Associated_Bloodstream_Infections: 2,
        Clostridium_Difficile_C_Diff_Infections: 22,
        MRSA_Bacteremia_Infections: 37, 
        Abdominal_Hysterectomy_Infections: 8, 
        SSI_Colon_Surgery_Infections: 12,
        Hospital_Acquired_Infections: 5
    },

    al: {
        Catheter_Associated_Urinary_Tract_Infections: 14,
        Central_Line_Associated_Bloodstream_Infections: 2,
        Clostridium_Difficile_C_Diff_Infections: 5,
        MRSA_Bacteremia_Infections: 15,
        Abdominal_Hysterectomy_Infections: 4, 
        SSI_Colon_Surgery_Infections: 7,
        Hospital_Acquired_Infections: 9
    }
};
