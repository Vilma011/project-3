# Project-3
This is Project 3 for Team #1

      Data Set
CMS Hospital Acquired Infections.
 https://data.cms.gov/
